var searchData=
[
  ['colorij',['colorIJ',['../d7/d0a/classRipplingMath.html#a63ac813d3453e3b7288144eed592e41f',1,'RipplingMath']]],
  ['colorxy',['colorXY',['../d0/d8e/classMandelbrotMath.html#aa23c2c50a815d793d1663e42fde162f4',1,'MandelbrotMath']]],
  ['createanimable',['createAnimable',['../d7/dfd/classRipplingProvider.html#a53aa7d617c33590cd542c844ebf1605b',1,'RipplingProvider::createAnimable()'],['../d9/d02/classMandelbrotProvider.html#ac64158aa1216bd6f8ddc7b4243de6c2e',1,'MandelbrotProvider::createAnimable()']]],
  ['createimagegl',['createImageGL',['../d7/dfd/classRipplingProvider.html#a0066f8b30d55fa67bff8308a44b9f999',1,'RipplingProvider::createImageGL()'],['../d9/d02/classMandelbrotProvider.html#a0a891347b6811769b5920daec3ec8dea',1,'MandelbrotProvider::createImageGL()']]]
];
