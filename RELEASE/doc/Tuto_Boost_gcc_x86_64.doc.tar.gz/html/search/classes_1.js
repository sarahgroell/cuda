var searchData=
[
  ['singletonboost',['SingletonBoost',['../df/d56/classSingletonBoost.html',1,'']]],
  ['singletonstd',['SingletonStd',['../d3/d75/classSingletonStd.html',1,'']]]
];
