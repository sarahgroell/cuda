var searchData=
[
  ['processentrelacementomp',['processEntrelacementOMP',['../d0/d8a/classImageVideo.html#a72116199a490a22bc4469fe4f294a55a',1,'ImageVideo']]],
  ['processforautoomp',['processForAutoOMP',['../d0/d8a/classImageVideo.html#a9275edaff8b0c8c297d5b646957a9329',1,'ImageVideo']]]
];
