var searchData=
[
  ['fois',['fois',['../db/d7c/integer_8cpp.html#a826fe3fd10d9eaf43deebbaefe15e9b7',1,'fois(int x1, int x2):&#160;integer.cpp'],['../d6/d3d/integer_8h.html#a826fe3fd10d9eaf43deebbaefe15e9b7',1,'fois(int x1, int x2):&#160;integer.cpp'],['../d5/d6b/scalar_8cpp.html#aefdb084c090606a498ef1f16d119cf5c',1,'fois(double x1, double x2):&#160;scalar.cpp'],['../db/d94/scalar_8h.html#aefdb084c090606a498ef1f16d119cf5c',1,'fois(double x1, double x2):&#160;scalar.cpp']]]
];
