var searchData=
[
  ['release',['release',['../de/d4a/classMyDisplayable.html#ab9e2688a89aab7c54a6528fff402f957',1,'MyDisplayable']]],
  ['reshape',['reshape',['../de/d4a/classMyDisplayable.html#aa89410db64aab32b85f4666737b030f0',1,'MyDisplayable']]]
];
